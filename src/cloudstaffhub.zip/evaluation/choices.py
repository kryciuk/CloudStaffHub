ANSWERS_CHOICES = (
    (1, "Strongly disagree"),
    (2, "Somewhat disagree"),
    (3, "Not sure"),
    (4, "Somewhat agree"),
    (5, "Strongly agree"),
)
