from django.contrib import admin

__all__ = ["admin"]
